import numpy as np
import torch
import torch.nn as nn
import torch.distributions as ptd

from network_utils import np2torch, device


class BasePolicy:
    def action_distribution(self, observations):
        """
        Args:
            observations: torch.Tensor of shape [batch size, dim(observation space)]
        Returns:
            distribution: instance of a subclass of torch.distributions.Distribution

        See https://pytorch.org/docs/stable/distributions.html#distribution

        This is an abstract method and must be overridden by subclasses.
        It will return an object representing the policy's conditional
        distribution(s) given the observations. The distribution will have a
        batch shape matching that of observations, to allow for a different
        distribution for each observation in the batch.
        """
        raise NotImplementedError

    def act(self, observations):
        """
        Args:
            observations: np.array of shape [batch size, dim(observation space)]
        Returns:
            sampled_actions: np.array of shape [batch size, *shape of action]

        TODO:
        Call self.action_distribution to get the distribution over actions,
        then sample from that distribution. You will have to convert the
        actions to a numpy array, via numpy(). Put the result in a variable
        called sampled_actions (which will be returned).
        """
        observations = np2torch(observations)
        #######################################################
        #########   YOUR CODE HERE - 1-3 lines.    ############
        return self.action_distribution(observations).sample().numpy()
        #######################################################
        #########          END YOUR CODE.          ############


class CategoricalPolicy(BasePolicy, nn.Module):
    def __init__(self, network):
        nn.Module.__init__(self)
        self.network = network

    def action_distribution(self, observations):
        """
        Args:
            observations: torch.Tensor of shape [batch size, dim(observation space)]
        Returns:
            distribution: torch.distributions.Categorical where the logits
                are computed by self.network

        See https://pytorch.org/docs/stable/distributions.html#categorical
        """
        #######################################################
        #########   YOUR CODE HERE - 1-2 lines.    ############
        # compute the logit
        # logit = self.network(observations)
        return torch.distributions.categorical.Categorical(
            logits=self.network(observations)
        )
        #######################################################
        #########          END YOUR CODE.          ############


class GaussianPolicy(BasePolicy, nn.Module):
    def __init__(self, network, action_dim):
        """
        After the basic initialization, you should create a nn.Parameter of
        shape [dim(action space)] and assign it to self.log_std.
        A reasonable initial value for log_std is 0 (corresponding to an
        initial std of 1), but you are welcome to try different values.
        """
        nn.Module.__init__(self)
        self.network = network
        param_tensor = torch.tensor([0. for _ in range(action_dim)])
        #######################################################
        #########   YOUR CODE HERE - 1 line.       ############
        self.log_std = nn.Parameter(
            torch.ones(action_dim)*-1, # ED: 885
            # param_tensor
        )
        #######################################################
        #########          END YOUR CODE.          ############

    def std(self):
        """
        Returns:
            std: torch.Tensor of shape [dim(action space)]

        The return value contains the standard deviations for each dimension
        of the policy's actions. It can be computed from self.log_std
        """
        #######################################################
        #########   YOUR CODE HERE - 1 line.       ############
        return torch.exp(self.log_std)
        #######################################################
        #########          END YOUR CODE.          ############

    def action_distribution(self, observations):
        """
        Args:
            observations: torch.Tensor of shape [batch size, dim(observation space)]
        Returns:
            distribution: an instance of a subclass of
                torch.distributions.Distribution representing a diagonal
                Gaussian distribution whose mean (loc) is computed by
                self.network and standard deviation (scale) is self.std()

        Note: PyTorch doesn't have a diagonal Gaussian built in, but you can
            fashion one out of
            (a) torch.distributions.MultivariateNormal
            or
            (b) A combination of torch.distributions.Normal
                             and torch.distributions.Independent
        """
        #######################################################
        #########   YOUR CODE HERE - 2-4 lines.    ############
        mu = self.network(observations) # predict mean
        sigma = torch.diag(
            torch.pow(self.std(), 2)
        ) # recover variance and style it as a covariance
        # print(mu.shape, sigma.shape) # sanity check
        # documentation here: https://pytorch.org/docs/stable/distributions.html#multivariatenormal
        return torch.distributions.MultivariateNormal(
            loc=mu,
            covariance_matrix=sigma
        )

        #######################################################
        #########          END YOUR CODE.          ############
        return distribution
